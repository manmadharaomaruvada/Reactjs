import React from 'react'

function Contactus() {
  return (
    <div>
        <h1>Contactus components</h1>
    </div>
  )
}

export default Contactus