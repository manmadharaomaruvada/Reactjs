import React from 'react'

function Service() {
  return (
    <div>
        <h1>
        Service components
        </h1>
    </div>
  )
}

export default Service