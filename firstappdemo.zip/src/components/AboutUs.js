import React from 'react'

function Aboutus() {
  return (
    <div>
        <h1>
        Aboutus components
        </h1>
    </div>
  )
}

export default Aboutus